/** @odoo-module **/

import { registry } from "@web/core/registry";
import { FormController } from "@web/views/form/form_controller";
import { ConfirmationDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
import { patch } from "@web/core/utils/patch";
const { DateTime, Info } = luxon;

class CustomFormController extends FormController {
    async onWillSaveRecord(record) {
        const recordData = this.model.root.data;
        const leaveType = recordData?.holiday_status_id?.[1];
        const leaveDateFrom = recordData?.request_date_from;
        const leaveDateTo = recordData?.request_date_to;

        const today = DateTime.now();

        const leaveDateFromStr = leaveDateFrom?.toISODate();
        const todayStr = today.toISODate();

        console.log("Leave Type:", leaveType);
        console.log("Leave Start Date:", leaveDateFromStr);
        // === Case 1: Same-day 7-Hour Policy Leave ===
        if (this.props.resModel === "hr.leave" && leaveType === "7-Hour Policy Leave") {
            if (leaveDateFromStr === todayStr) {
                const confirmed = await new Promise((resolve) => {
                    this.env.services.dialog.add(ConfirmationDialog, {
                        title: "Same-Day Leave Confirmation",
                        body: "You're applying for same-day '7-Hour Policy Leave'. This is allowed only twice per year. Do you want to continue?",
                        confirm: () => resolve(true),
                        cancel: () => resolve(false),
                    });
                });

                if (!confirmed) return false;

                this.model.root.update({
                    is_same_day_confirmed: true,
                    to_be_continue: true,
                });
            }
        }
        // === Case 2: Casual Leave with less than 4 days' notice ===
          if (this.props.resModel === "hr.leave" && leaveType === "Casual Leave" && leaveDateFromStr) {
            const leaveDateFrom = DateTime.fromISO(leaveDateFromStr);
            const daysNotice = leaveDateFrom.diff(today, 'days').days;
            console.log("==============",this.model.root.update)
            if (daysNotice < 4) {
            console.log(">>>>>>>>>>>>44444444444444")
                const confirmed = await new Promise((resolve) => {
                    this.env.services.dialog.add(ConfirmationDialog, {
                        title: "Short Notice - Casual Leave",
                        body: "You're applying for 'Casual Leave' with less than 4 days' notice. Are you sure you want to proceed?",
                        confirm: () => resolve(true),
                        cancel: () => resolve(false),
                    });
                });
                if (!confirmed) return false;

                this.model.root.update({
                    is_same_day_confirmed_cl: true,
                    to_be_continue_cl: true,
                });
            }
        }

        return super.onWillSaveRecord(record);
    }
}

// Patch the controller into the registry
const formView = registry.category("views").get("form");
formView.Controller = CustomFormController;
