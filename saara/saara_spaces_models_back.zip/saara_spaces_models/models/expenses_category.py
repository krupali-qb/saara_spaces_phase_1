from odoo import fields, models, api


class ProjectExpenses(models.Model):
    _name = "expenses.category"
    _description = 'Project Expenses category'

    name = fields.Char(string="Name", required=True, size=50)

    @api.onchange('name')
    def _onchange_name(self):
        if self.name:
            self.name = self.name.title()


class AgencyCategory(models.Model):
    _name = "agency.category"
    _description = 'Project agency category'

    name = fields.Char(string="Name", required=True, size=100)

    @api.onchange('name')
    def _onchange_name(self):
        if self.name:
            self.name = self.name.title()


class VendorPaymentMethod(models.Model):
    _inherit = "vendor.payment.method"
    #
    disable_add_line = fields.Boolean(compute='_compute_disable_add_line', store=True)
    #
    # @api.depends('project_form_id')
    # def _compute_disable_add_line(self):
    #     for order in self:
    #         # When the order is not saved yet (new), allow adding lines
    #         if not order.id:
    #             order.disable_add_line = False
    #         else:
    #             print("===============disable")
    #             # Disable "Add a line" only when there is exactly 1 line
    #             order.disable_add_line = len(order.project_form_id) == 1