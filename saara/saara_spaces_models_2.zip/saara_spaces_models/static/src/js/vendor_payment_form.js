/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { X2ManyField } from "@web/views/fields/x2many/x2many_field";

patch(X2ManyField.prototype, {
    setup() {
        super.setup();
        const isVendorPaymentMethod = this.props.record.resModel === "vendor.payment.method";
        const isProjectFormField = this.props.name === "project_form_id";
        const isRecordSaved = this.props.record.resId !== null;

        const recordData = this.props.record.data;
        const lineCount = recordData?.project_form_id?.count || 0;
        const hasOneLine = lineCount >= 1;


        console.log("======>",hasOneLine)
        if (isVendorPaymentMethod && isProjectFormField && isRecordSaved && hasOneLine) {
            console.log("===========1111111ifffffffffff")
            this.canCreate = false;
        }
    }
});
